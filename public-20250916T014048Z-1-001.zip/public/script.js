    function checkFunction() {
      window.location.href = "main.html";
    }
    function settingsFunction() {
      window.location.href = "settings.html";
    }
     function homeFunction() {
      window.location.href = "home.html";
    }

